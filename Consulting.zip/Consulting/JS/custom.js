$(document).on('ready', function() {
	$(".regular").slick({
		dots: true,
        arrows: false,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
         responsive: [
            {
                breakpoint: 570,
                settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
            }
            },
        
            {
                breakpoint: 321,
                settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }   
            }
        ]
    });

    $(".testimonial-slider").slick({
        dots: true,
        arrows: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1
    });
});