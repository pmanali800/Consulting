$(document).on('ready', function() {

  /*tab-content*/

  $('.tab-content .tab-title').click(function(){               
    $('.tab-content .tab-title').not(this).removeClass('is-open');
    $('.tab-content .tab-title').not(this).next().slideUp(350);
    $(this).toggleClass('is-open');
    $(this).next().slideToggle(350);              
  });

  $('.tab-content-mobile .tab-title-mobile').click(function(){               
    $('.tab-content-mobile .tab-title-mobile').not(this).removeClass('is-open');
    $('.tab-content-mobile .tab-title-mobile').not(this).next().slideUp(350);
    $(this).toggleClass('is-open');
    $(this).next().slideToggle(350);              
  });

  /*mobile-menu*/

  var theToggle = document.getElementById('toggle');
  function hasClass(elem, className) {
    return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
  }

  function addClass(elem, className) {
      if (!hasClass(elem, className)) {
        elem.className += ' ' + className;
      }
  }

  function removeClass(elem, className) {
  var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, ' ') + ' ';
  if (hasClass(elem, className)) {
        while (newClass.indexOf(' ' + className + ' ') >= 0 ) {
            newClass = newClass.replace(' ' + className + ' ', ' ');
        }
          elem.className = newClass.replace(/^\s+|\s+$/g, '');
      }
  }

  function toggleClass(elem, className) {
  var newClass = ' ' + elem.className.replace( /[\t\r\n]/g, " " ) + ' ';
    if (hasClass(elem, className)) {
        while (newClass.indexOf(" " + className + " ") >= 0 ) {
            newClass = newClass.replace( " " + className + " " , " " );
        }
          elem.className = newClass.replace(/^\s+|\s+$/g, '');
      } else {
          elem.className += ' ' + className;
      }
  }

  theToggle.onclick = function(){
    toggleClass(this, 'on');
    return false;
}

  /*sticky-header*/

  $(window).scroll(function() {
    if ($(document).scrollTop() > 1) {
      $(".header").addClass("sticky");
    } else {
      $(".header").removeClass("sticky");
    }
  });

  /*bottom-to-top scroll*/

  $(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        
      $('#return-to-top').fadeIn(200);    
    } 
    else {
      $('#return-to-top').fadeOut(200);   
    }
  });

  $('#return-to-top').click(function() {      
    $('body,html').animate({
      scrollTop : 0                       
    }, 500);
  });

	/*banner*/

	$(".vertical").slick({
    dots: false,
    arrows: true,
    slidesToShow: 1,
    slidesToScroll: 1
  });

  $(".regular").slick({
    dots: false,
    arrows: true,
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 6,
    responsive: [
    {
      breakpoint: 1025,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
      }
    },
    {
      breakpoint: 769,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 570,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});

	/*counter*/
	
  $('.counting').each(function() {
  	var $this = $(this),
    countTo = $this.attr('data-count');
  
  	$({ countNum: $this.text()}).animate({
    	countNum: countTo
  	},

  	{
      duration: 6000,
    	easing:'linear',
    	step: function() {
      	$this.text(Math.floor(this.countNum));
      },

    	complete: function() {
      	$this.text(this.countNum);
      }
  	});  
  });
});